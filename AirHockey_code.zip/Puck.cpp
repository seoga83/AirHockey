#include "framework.h"
#include "Puck.h"
#include "PaddleParent.h"
#include "GlobalValues.h"
#include "Paddle01.h"
#include "Paddle02.h"
#include "UIMgr.h"

void Puck::Init_Unit(HWND a_hWnd)
{
	m_SocketImg = Image::FromFile(_T(".\\Images\\graphics_airhockey_puck.png"));
	LoadUnitSize();

	//-------Puck ��ǥ �ʱ�ȭ �κ�
	RECT a_Crt;
	GetClientRect(a_hWnd, &a_Crt);   //Main DC �� ���� ���� ����� ������ �Լ� 
	m_CurPos.x = (float)(a_Crt.right / 2);
	m_CurPos.y = (float)(a_Crt.bottom / 2);
	m_InitPos = m_CurPos;
	//-------Puck ��ǥ �ʱ�ȭ �κ�

	m_hWnd = a_hWnd;
}

void Puck::Update_Unit(float a_DeltaTime, RECT& a_RT)
{
	m_DeltaTime = a_DeltaTime;

	//KBMove();

	m_CurPos = m_CurPos + (m_DirVec * (a_DeltaTime * m_Speed));

	LimitMove();

	GoalJudge();
}

void Puck::Render_Unit(HDC a_hDC)
{
	Graphics graphics(a_hDC);

	if (m_SocketImg != NULL)
	{
		graphics.DrawImage(m_SocketImg,
			m_CurPos.x - (m_SocketImg->GetWidth() / 2.0f),
			m_CurPos.y - (m_SocketImg->GetHeight() / 2.0f),
			m_SocketImg->GetWidth(),
			m_SocketImg->GetHeight());
	}//if (m_SocketImg != NULL)

	/*TCHAR str[128];
	_stprintf_s(str, L"%f : %f", m_CurPos.x, m_CurPos.y);
	TextOut(a_hDC, 300, 100, str, _tcslen(str));*/
}

void Puck::Destroy_Unit()
{
	if (m_SocketImg != NULL)
	{
		delete m_SocketImg;
		m_SocketImg = NULL;
	}
}

void Puck::LoadUnitSize()
{
	if (m_SocketImg != NULL)
	{
		m_ImgSizeX = m_SocketImg->GetWidth();     //�⺻ �̹����� ���� ������
		m_ImgSizeY = m_SocketImg->GetHeight();	  //�⺻ �̹����� ���� ������

		m_HalfWidth = m_ImgSizeX / 2;			  //�⺻ �̹����� ���� �ݻ�����
		m_HalfHeight = m_ImgSizeY / 2;			  //�⺻ �̹����� ���� �ݻ�����

		m_ColRadius = m_HalfHeight - 5;
	}
}

void Puck::KBMove()
{
	//--------����Ű ó�� ���(�밢�� �̵��� ����)
	static Vector2D a_CacDir;
	a_CacDir.x = 0.0f;
	a_CacDir.y = 0.0f;

	if ((GetAsyncKeyState(VK_LEFT) & 0x8000) ||
		(GetAsyncKeyState('A') & 0x8000))
	{
		a_CacDir.x -= 1.0f;
	}
	if ((GetAsyncKeyState(VK_RIGHT) & 0x8000) ||
		(GetAsyncKeyState('D') & 0x8000))
	{
		a_CacDir.x += 1.0f;
	}
	if ((GetAsyncKeyState(VK_UP) & 0x8000) ||
		(GetAsyncKeyState('W') & 0x8000))
	{
		a_CacDir.y -= 1.0f;
	}
	if ((GetAsyncKeyState(VK_DOWN) & 0x8000) ||
		(GetAsyncKeyState('S') & 0x8000))
	{
		a_CacDir.y += 1.0f;
	}
	//--------����Ű ó�� ���(�밢�� �̵��� ����)

	if (a_CacDir.x != 0.0f || a_CacDir.y != 0.0f)
	{
		a_CacDir.Normalize(); //���̰� 1�� ����
		m_CurPos = m_CurPos + (a_CacDir * (m_DeltaTime * 300));//m_Speed));
	}
}

void Puck::LimitMove()
{
	// (45, 40) (556, 760)
	if (m_CurPos.x < 45)
	{
		m_CurPos.x = 45;
		m_DirVec.x = -m_DirVec.x;
	}
	else if (m_CurPos.x > 556)
	{
		m_CurPos.x = 556;
		m_DirVec.x = -m_DirVec.x;
	}
	if ((m_CurPos.y < 40/* && m_CurPos.y > 30*/) && (m_CurPos.x < 175 || m_CurPos.x > 425))
	{
		m_CurPos.y = 40;
		m_DirVec.y = -m_DirVec.y;
	}
	else if ((m_CurPos.y > 760/* && m_CurPos.y < 770*/) && (m_CurPos.x < 175 || m_CurPos.x > 425))
	{
		m_CurPos.y = 760;
		m_DirVec.y = -m_DirVec.y;
	}
}

void Puck::ColWithPaddle(PaddleParent* Paddle)
{
	a_CacVec = Paddle->m_CurPos - m_CurPos;
	a_CacSDist = a_CacVec.Magnitude();
	a_RadiusHap = m_ColRadius + Paddle->m_ColRadius; //(���ݰ� + ���ݰ�) ���� ��Ȱ��
	if (a_CacSDist < a_RadiusHap) //��ģ ����
	{
		a_CacMovePos = Paddle->m_CurPos;
		a_CacMargin = a_RadiusHap - a_CacSDist;
		a_CacSNormal = a_CacVec; //�з����� ����
		a_CacSNormal.Normalize();
		a_CacShiftLen = a_CacMargin;
		if (a_RadiusHap < a_CacShiftLen) //������ġ �з��� �ϴ� ���� ���������� Ŀ���� �ȵȴ�. 
		{
			a_CacShiftLen = a_RadiusHap;
		}
		a_CacMovePos = a_CacMovePos + (a_CacSNormal * a_CacShiftLen);
		Paddle->m_CurPos = a_CacMovePos;
		static Vector2D tempV = m_DirVec;
		tempV = m_DirVec;
		m_DirVec = -1 * a_CacSNormal;
		
		m_Speed = Paddle->m_Speed * 1;
		if (m_Speed <= 200)
		{
			m_Speed = 200.0f;
			m_DirVec = m_DirVec + tempV;
			m_DirVec.Normalize();
		}
		else if (m_Speed > 1300)
			m_Speed = 1300.0f;
	}//if (a_CacSDist < a_RadiusHap)
}

void Puck::GoalJudge()
{
	if (m_CurPos.y > 800)
	{
		g_scorePaddle02++;
		//Reset();
		g_GameState = Goal;
		g_UIMgr.isPaddle01Goal = false;
		g_Paddle02.Reset();
	}
	else if (m_CurPos.y < 0)
	{
		g_scorePaddle01++;
		//Reset();
		g_GameState = Goal;
		g_UIMgr.isPaddle01Goal = true;
		g_Paddle02.Reset();
	}
}

void Puck::Reset()
{ 
	m_CurPos = m_InitPos;
	m_Speed = 0;
	m_DirVec.x = 0;
	m_DirVec.y = 0;
	g_Paddle01.Reset();
	g_Paddle02.Reset();
}

Puck g_Puck;